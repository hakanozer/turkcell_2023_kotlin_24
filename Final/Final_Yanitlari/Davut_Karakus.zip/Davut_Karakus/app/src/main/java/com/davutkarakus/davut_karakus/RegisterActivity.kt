package com.davutkarakus.davut_karakus

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    lateinit var isimEditText : EditText
    lateinit var soyadEditText: EditText
    lateinit var mailEditText: EditText
    lateinit var sifreEditText: EditText
    private lateinit var kayitButton : ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val preferences = getSharedPreferences("kullanicilar", MODE_PRIVATE)
        val editor = preferences.edit()

        isimEditText = findViewById(R.id.nameEditText)
        soyadEditText = findViewById(R.id.soyadEditText)
        mailEditText = findViewById(R.id.mailEditText)
        sifreEditText = findViewById(R.id.sifreEditText)
        kayitButton = findViewById(R.id.buttonKayit)

        kayitButton.setOnClickListener {

            if (isimEditText.text.toString() == "") {
                println("burası")
                Toast.makeText(this,"Lütfen Adınızı Giriniz",Toast.LENGTH_LONG).show()
            }
            else if(soyadEditText.text.toString() == "") {
                Toast.makeText(this,"Lütfen Soyadınızı Giriniz",Toast.LENGTH_LONG).show()
            }
            else if(mailEditText.text.toString() == "") {
                Toast.makeText(this,"Lütfen Mailinizi Giriniz",Toast.LENGTH_LONG).show()
            }
            else if(sifreEditText.text.toString() == "") {
                Toast.makeText(this,"Lütfen Şifrenizi Giriniz",Toast.LENGTH_LONG).show()
            }
            else {
                editor.putString("kAd",isimEditText.text.toString())
                editor.putString("kSoyad",soyadEditText.text.toString())
                editor.putString("kMail",mailEditText.text.toString())
                editor.putString("kSifre",sifreEditText.text.toString())
                editor.commit()
                Toast.makeText(this,"Kayıt Başarılı Oldu",Toast.LENGTH_LONG).show()
                val intent = Intent(this,LoginActivity::class.java)
                startActivity(intent)
            }
        }

    }
}
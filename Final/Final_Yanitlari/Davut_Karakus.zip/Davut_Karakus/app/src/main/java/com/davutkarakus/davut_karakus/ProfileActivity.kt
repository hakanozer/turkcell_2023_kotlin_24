package com.davutkarakus.davut_karakus

import android.content.Context
import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {
    lateinit var nameText : TextView
    lateinit var mailText : TextView
    lateinit var logOutBtn : ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val preferences = getSharedPreferences("kullanicilar",MODE_PRIVATE)
        val editor = preferences.edit()
        val name = preferences.getString("kAd","")
        val mail = preferences.getString("kMail","")
        val soyad = preferences.getString("kSoyad","")

        nameText = findViewById(R.id.profileIsımText)
        mailText = findViewById(R.id.profileMailText)
        logOutBtn = findViewById(R.id.logOutButton)
        nameText.text = "Sn.$name $soyad"
        mailText.text = mail
        logOutBtn.setOnClickListener {
            editor.clear()
            editor.commit()
            val intent = Intent(this,RegisterActivity::class.java)
            startActivity(intent)
        }

    }
}
package com.davutkarakus.davut_karakus

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    lateinit var mailEditText : EditText
    lateinit var sifreEditText: EditText
    lateinit var loginBtn : ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val preferences = getSharedPreferences("kullanicilar", MODE_PRIVATE)

        val mail = preferences.getString("kMail","")
        val sifre = preferences.getString("kSifre","")

        mailEditText = findViewById(R.id.mailGirisEditText)
        sifreEditText = findViewById(R.id.sifreGirisEditText)
        loginBtn = findViewById(R.id.loginButton)

        loginBtn.setOnClickListener {
            if (mailEditText.text.toString() == "") {
                Toast.makeText(this,"Lütfen Mailinizi Giriniz",Toast.LENGTH_LONG).show()
            }else if (sifreEditText.text.toString() == "") {
                Toast.makeText(this,"Lütfen Şifrenizi Giriniz",Toast.LENGTH_LONG).show()
            }else  if(mail != mailEditText.text.toString()){
                Toast.makeText(this,"Mailinizi Yanlış Girdiniz",Toast.LENGTH_LONG).show()
            } else if (sifre != sifreEditText.text.toString()) {
                Toast.makeText(this,"Şifrenizi Yanlış Girdiniz",Toast.LENGTH_LONG).show()
            }else {
                val intent = Intent(this,ProfileActivity::class.java)
                startActivity(intent)
                Toast.makeText(this,"Kullanıcı Girişi Başarılı",Toast.LENGTH_LONG).show()
            }
        }
    }
}
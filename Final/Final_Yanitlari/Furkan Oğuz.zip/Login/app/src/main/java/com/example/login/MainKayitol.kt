package com.example.login

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.login.databinding.ActivityMainKayitolBinding

class MainKayitol : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainKayitolBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnkayit.setOnClickListener(){
            var kullaniciad = binding.kayitad.text.toString()
            var kullanicisoyad = binding.kayitsoyad.text.toString()
            var kullanicimail = binding.kayitmail.text.toString()
            var kullaniciparola = binding.kayitparola.text.toString()
            var SharedPreferences = this.getSharedPreferences("Bilgiler", MODE_PRIVATE)
            var editor = SharedPreferences.edit()
            editor.putString("Kullaniciad","$kullaniciad").apply()
            editor.putString("Parola","$kullaniciparola").apply()
            editor.putString("Kullaicisoyad","$kullanicisoyad").apply()
            editor.putString("Kullaicimail","$kullanicimail").apply()
            Toast.makeText(applicationContext,"Kayıt Başarılı",Toast.LENGTH_LONG).show()
            binding.kayitad.text.clear()
            binding.kayitsoyad.text.clear()
            binding.kayitmail.text.clear()
            binding.kayitparola.text.clear()

        }

        binding.buttoncikis.setOnClickListener{
            intent = Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)


        }




    }
}
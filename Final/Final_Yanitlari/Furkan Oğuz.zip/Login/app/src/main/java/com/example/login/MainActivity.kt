package com.example.login

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.login.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var preferences:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences=getSharedPreferences("Bilgiler", MODE_PRIVATE)

        binding.btnGirisyap.setOnClickListener{


            var kayitliKulLanicimail =preferences.getString("kullanicimail"," ")
            var kayitliKulLaniciparola =preferences.getString("kullaniciparola"," ")

            var girisKullanici = binding.girisKullaniciadi.text.toString()
            var girisparola = binding.girisparola.text.toString()

            if ((kayitliKulLanicimail == girisKullanici) && (kayitliKulLaniciparola == girisparola)){
                Toast.makeText(applicationContext,"Giriş bilgileri Hatalı",Toast.LENGTH_LONG).show()

            }else
            {
                intent = Intent(applicationContext,MainLog::class.java)
                startActivity(intent)
            }




        }
        binding.btnkayiol.setOnClickListener{
            intent = Intent(applicationContext,MainKayitol::class.java)
            startActivity(intent)
        }

    }





}
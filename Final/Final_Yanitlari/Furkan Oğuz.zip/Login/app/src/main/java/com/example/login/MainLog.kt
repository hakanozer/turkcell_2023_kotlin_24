package com.example.login

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import com.example.login.databinding.ActivityMainLogBinding

class MainLog : AppCompatActivity() {
    lateinit var preferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityMainLogBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = getSharedPreferences("Bilgiler", MODE_PRIVATE)

        var kayitliKullanici =preferences.getString("Kullaniciad"," ")
        var kayitlimail =preferences.getString("Kullaicimail"," ")
        binding.Kullanicibilgisi.text = "Kullanici mail"+ kayitlimail.toString()
        binding.kullaniciadi.text = "Kullanici Adi"+ kayitliKullanici.toString()

        binding.btncikis.setOnClickListener{
            intent = Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)


        }





    }
}
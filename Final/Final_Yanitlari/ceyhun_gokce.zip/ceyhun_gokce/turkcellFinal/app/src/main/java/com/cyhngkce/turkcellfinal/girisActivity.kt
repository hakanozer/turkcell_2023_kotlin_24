package com.cyhngkce.turkcellfinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class girisActivity : AppCompatActivity() {
    lateinit var loginButton: ImageButton
    lateinit var emailTextGiris: EditText
    lateinit var passwordTextGiris: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris)
        loginButton=findViewById(R.id.loginButton)
        emailTextGiris=findViewById(R.id.emailTextGiris)
        passwordTextGiris=findViewById(R.id.passwordTextGiris)

        loginButton.setOnClickListener{
            val isim=intent.getStringExtra("isim")
            val soyisim=intent.getStringExtra("soyisim")
            val emailKontrol=intent.getStringExtra("email")
            val passwordKontrol=intent.getStringExtra("password")
            val email=emailTextGiris.text.toString()
            val password=passwordTextGiris.text.toString()

            if(email!="" && email==emailKontrol && password!="" && password==passwordKontrol){
                val intent= Intent(this,profileActivity::class.java)
                intent.putExtra("isim",isim)
                intent.putExtra("soyisim",soyisim)
                intent.putExtra("email",email)
                Toast.makeText(this, "Giriş Yapıldı.", Toast.LENGTH_SHORT).show()
                startActivity(intent)
                finish()

            }
            else{
                Toast.makeText(this, "Yanlış email veya şifre girdiniz.Tekrar deneyiniz.", Toast.LENGTH_LONG).show()
            }
        }

    }
}
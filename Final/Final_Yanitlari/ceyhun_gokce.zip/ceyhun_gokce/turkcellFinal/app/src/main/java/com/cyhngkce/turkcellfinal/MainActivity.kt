package com.cyhngkce.turkcellfinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var registerButton: ImageButton
    lateinit var emailText: EditText
    lateinit var passwordText: EditText
    lateinit var isimText: EditText
    lateinit var soyisimText: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        registerButton=findViewById(R.id.registerButton)
        emailText=findViewById(R.id.emailText)
        passwordText=findViewById(R.id.passwordText)
        isimText=findViewById(R.id.isimText)
        soyisimText=findViewById(R.id.soyisimText)

        val shared=getSharedPreferences("kullanicilar", MODE_PRIVATE)
        val editor=shared.edit()

        registerButton.setOnClickListener {
            val isim=isimText.text.toString()
            val soyisim=soyisimText.text.toString()
            val email=emailText.text.toString()
            val password=passwordText.text.toString()

            editor.putString("isim",isim)
            editor.putString("soyisim",soyisim)
            editor.putString("email",email)
            editor.putString("password",password)

            editor.commit()

            if(email!="" && password!="" && isim!="" && soyisim!=""){
                val intent=Intent(this,girisActivity::class.java)

                intent.putExtra("email",email)
                intent.putExtra("password",password)
                intent.putExtra("isim",isim)
                intent.putExtra("soyisim",soyisim)

                startActivity(intent)
                Toast.makeText(this, "Kayıt olundu.", Toast.LENGTH_SHORT).show()
                finish()

            }
            else{
                Toast.makeText(this, "Eksik bilgi girdiniz.", Toast.LENGTH_SHORT).show()
            }

        }

    }
}
package com.cyhngkce.turkcellfinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast

class profileActivity : AppCompatActivity() {
    lateinit var isimSoyisimText: TextView
    lateinit var mailText:TextView
    lateinit var cikisButton: ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        isimSoyisimText=findViewById(R.id.isimSoyisimText)
        mailText=findViewById(R.id.mailText)
        cikisButton=findViewById(R.id.cikisButton)
        val isim=intent.getStringExtra("isim")
        val soyisim=intent.getStringExtra("soyisim")
        val email=intent.getStringExtra("email")
        isimSoyisimText.setText("Sayın ${isim} ${soyisim}")
        mailText.setText("${email}")

        cikisButton.setOnClickListener {
            val sharedPreferences = getSharedPreferences("kullanicilar", MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.remove("isim")
            editor.remove("soyisim")
            editor.remove("email")
            editor.remove("password")
            editor.apply()
            val kayitEkraniYonlendirme=Intent(this,MainActivity::class.java)
            Toast.makeText(this, "Çıkış Yapıldı.", Toast.LENGTH_SHORT).show()
            startActivity(kayitEkraniYonlendirme)
            finish()

            
        }
    }
}
package com.baran.gyproje

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.baran.gyproje.databinding.ActivityMainBinding
import com.baran.gyproje.databinding.ActivityMainKayitBinding
import com.baran.gyproje.databinding.ActivityMainProfileBinding

class MainKayit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainKayitBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnKayit.setOnClickListener{
            var kullaniciAdi = binding.KayitAdi.text.toString()
            var kullaniciSoyadi = binding.KayitSoyadi.text.toString()
            var kullaniciMail = binding.KayitMail.text.toString()
            var kullaniciName = binding.KayitName.text.toString()
            var sharedPreferences = this.getSharedPreferences("bilgiler", MODE_PRIVATE)
            var editor = SharedPreferences.edit()

            editor.putString("kullaniciadi","$kullaniciAdi").apply()
            editor.putString("kullanicisoyadi","$kullaniciSoyadi").apply()
            editor.putString("kullanicimail","$kullaniciMail").apply()
            editor.putString("kullaniciname","$kullaniciName").apply()
            Toast.makeText(applicationContext, "Kayit Başarılı", Toast.LENGTH_SHORT).show()
            binding.KayitAdi.text.clear()
            binding.KayitSoyadi.text.clear()
            binding.KayitMail.text.clear()
            binding.KayitName.text.clear()




        }

        binding.btnKayit.setOnClickListener {
            intent = Intent(applicationContext, MainKayit::class.java)
            startActivity(intent)

        }
    }
}
package com.baran.gyproje

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.baran.gyproje.databinding.ActivityMainKayitBinding
import com.baran.gyproje.databinding.ActivityMainProfileBinding

class MainProfile : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainProfileBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main_profile)
        binding.buttonCikis.setOnClickListener {
            intent = Intent(applicationContext, MainKayit::class.java)
            startActivity(intent)
        }
    }
}
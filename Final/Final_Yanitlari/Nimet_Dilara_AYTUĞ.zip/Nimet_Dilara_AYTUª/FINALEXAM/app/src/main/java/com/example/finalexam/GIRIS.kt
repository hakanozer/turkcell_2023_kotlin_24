package com.example.finalexam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton

class GIRIS : AppCompatActivity() {
    lateinit var txtLoginEmail : EditText
    lateinit var txtLoginPassword : EditText
    lateinit var btnLogin : ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris)

        txtLoginEmail = findViewById(R.id.txtLoginEmail)
        txtLoginPassword = findViewById(R.id.txtLoginPassword)
        btnLogin = findViewById(R.id.btnLogin)

        val email = txtLoginEmail.text.toString().trim().replace(" ", "")
        val password = txtLoginPassword.text.toString().trim()


        }
        )
        }




    }
}
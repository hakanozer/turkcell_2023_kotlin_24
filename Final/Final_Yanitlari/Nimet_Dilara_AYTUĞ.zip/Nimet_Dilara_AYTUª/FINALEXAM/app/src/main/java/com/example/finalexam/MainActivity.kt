package com.example.finalexam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var txtAdi : EditText
    lateinit var txtSoyadi : EditText
    lateinit var txtMail : EditText
    lateinit var txtSifre : EditText
    lateinit var btnKayitOl : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txtAdi = findViewById(R.id.txtAdi)
        txtSoyadi = findViewById(R.id.txtSoyadi)
        txtMail = findViewById(R.id.txtMail)
        txtSifre = findViewById(R.id.txtSifre)
        btnKayitOl = findViewById(R.id.btnKayitOl)

        btnKayitOl.setOnClickListener {
            val adi = txtAdi.text.toString().trim().replace("","")
            val soyadi = txtSoyadi.text.toString().trim().replace("","")
            val email =  txtMail.text.toString().trim().replace("","")
            val sifre = txtSifre.text.toString().trim()

            val shared = getSharedPreferences("users", MODE_PRIVATE)
            val editor = shared.edit()



            if (email.equals("")){
                Toast.makeText(this,"E-mail BOS!", Toast.LENGTH_SHORT).show()

            }else if (sifre.equals("")){
                Toast.makeText(this, "SIFRE BOS!",Toast.LENGTH_SHORT).show()

            } else if (adi.equals("")){
                Toast.makeText(this,"ADI BOS!",Toast.LENGTH_SHORT).show()

            } else if (soyadi.equals("")){
                Toast.makeText(this,"SOYADI BOS!",Toast.LENGTH_SHORT).show()


            }else
            { val intent = Intent(this@MainActivity,GIRIS::class.java)

                startActivity(intent)
                Toast.makeText(this@MainActivity,"KAYIT BASARILI OLDU",Toast.LENGTH_LONG).show()


            }



        }


}
    }

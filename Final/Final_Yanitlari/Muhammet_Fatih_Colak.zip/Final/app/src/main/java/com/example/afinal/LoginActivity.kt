package com.example.afinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton

class LoginActivity : AppCompatActivity() {

    var pullData1 = ""
    var pullData2 = ""

    private lateinit var txtLoginEmail: EditText
    private lateinit var txtLoginPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val edit = shared.edit()

        val email = shared.getString("email", "")
        val password = shared.getString("password", "")




        txtLoginEmail = findViewById(R.id.txtLoginEmaill)
        txtLoginPassword = findViewById(R.id.txtLoginPasswordd)
        val data1 = intent.getStringExtra("key1")
        if ( data1 != null ) {
            this.pullData1 = data1
        }
        val data2 = intent.getStringExtra("key2")
        if ( data2 != null ) {
            this.pullData2 = data2
        }

        btnLogin.setOnClickListener {
            if(email.equals(pullData1) && password.equals(pullData2)) {
                val emaill = txtLoginEmail.text.toString()
                val passwordd = txtLoginPassword.text.toString()
                edit.putString("email", emaill)
                edit.putString("password", passwordd)
                edit.commit()

                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
            }

        }


    }
}
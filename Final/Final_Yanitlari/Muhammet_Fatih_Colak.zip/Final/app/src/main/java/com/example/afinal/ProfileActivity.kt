package com.example.afinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {

    private lateinit var txtName: TextView
    private lateinit var txtEmailView: TextView
    lateinit var btnExit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        txtName = findViewById(R.id.txtNamee)
        txtEmailView = findViewById(R.id.txtEmail)
        btnExit = findViewById(R.id.btnExit)

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val email = shared.getString("email", "")
        val name = shared.getString("name", "")

        txtEmailView.setText(email)
        txtName.setText(name)


        btnExit.setOnClickListener {
            val edit = shared.edit()
            edit.remove("email")
            edit.remove("")
            edit.commit()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
package com.example.afinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var txtName: EditText
    private lateinit var txtSurname: EditText
    private lateinit var txtLoginEmail: EditText
    private lateinit var txtLoginPassword: EditText
    private lateinit var btnLoginRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtName =findViewById(R.id.txtName)
        txtSurname= findViewById(R.id.txtSurname)
        txtLoginEmail = findViewById(R.id.txtLoginEmail)
        txtLoginPassword = findViewById(R.id.txtLoginPassword)
        btnLoginRegister = findViewById(R.id.btnSave)

        btnLoginRegister.setOnClickListener{

            val name = txtName.text.toString().trim()
            val surname = txtSurname.text.toString().trim()
            val email = txtLoginEmail.text.toString().trim().replace(" ", "")
            val password = txtLoginPassword.text.toString().trim()

            if (name == ""){
                Toast.makeText(this, "Name is empty!", Toast.LENGTH_SHORT).show()
            }
            else if (surname == ""){
                Toast.makeText(this, "Surname is empty!", Toast.LENGTH_SHORT).show()

            }
            else if (email == ""){
                Toast.makeText(this, "Email is empty!", Toast.LENGTH_SHORT).show()
            }
            else if (!isValidEmail(email)){
                Toast.makeText(this, "Email Format Fail!", Toast.LENGTH_SHORT).show()

            }
            else if ( password == "" ) {
                Toast.makeText(this, "Password Empty!", Toast.LENGTH_SHORT).show()
            }

            val intent = Intent(this, LoginActivity::class.java)
            val txtMail = txtLoginEmail.text.toString()
            intent.putExtra("key1", txtMail)
            val txtPass = txtLoginPassword.text.toString()
            intent.putExtra("key2", txtPass)
            startActivity(intent)

        }


    }

    fun isValidEmail(email: String): Boolean {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }


}
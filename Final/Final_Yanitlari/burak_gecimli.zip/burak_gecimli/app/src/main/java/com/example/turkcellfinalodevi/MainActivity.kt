package com.example.turkcellfinalodevi

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var txtSaveName: EditText
    lateinit var txtSaveSurName: EditText
    lateinit var txtSaveEmail: EditText
    lateinit var txtSavePassword: EditText
    lateinit var btnSave: ImageButton
    lateinit var userModel: UserModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtSaveName = findViewById(R.id.txtSaveName)
        txtSaveSurName = findViewById(R.id.txtSaveSurName)
        txtSaveEmail = findViewById(R.id.txtSaveEmail)
        txtSavePassword = findViewById(R.id.txtSavePassword)
        btnSave = findViewById(R.id.btnSave)


        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val email = shared.getString("email", "")
        val password = shared.getString("password", "")
        if (email.equals(email) && password.equals(password)) {
            val intent = Intent(this, Action::class.java)
            startActivity(intent)

        }



        btnSave.setOnClickListener {

            val name = txtSaveName.text.toString().trim().replace(" ", "")
            val surname = txtSaveSurName.text.toString().trim().replace(" ", "")
            val email = txtSaveEmail.text.toString().trim().replace(" ", "")
            val password = txtSavePassword.text.toString().trim().replace(" ", "")

            userModel = UserModel(name, surname, email, password)


            if (name == "") {
                Toast.makeText(this, "Name Empty!", Toast.LENGTH_LONG).show()
            } else if (surname == "") {
                Toast.makeText(this, "Surname Empty!", Toast.LENGTH_LONG).show()
            } else if (email == "") {
                Toast.makeText(this, "Email Empty!", Toast.LENGTH_LONG).show()
            } else if (password == "") {
                Toast.makeText(this, "Password Empty!", Toast.LENGTH_LONG).show()
            } else {
                //Tüm Datalar kontrol edildi.Shared Prefernce a kaydet ve diğer sayfaya intent yap


                val edit = shared.edit()

                edit.putString("name", userModel.name)
                edit.putString("surname", userModel.surname)
                edit.putString("email", userModel.email)
                edit.putString("password", userModel.password)
                edit.commit()

                val intent = Intent(this, UserLogin::class.java)
                startActivity(intent)


            }


        }


    }


}
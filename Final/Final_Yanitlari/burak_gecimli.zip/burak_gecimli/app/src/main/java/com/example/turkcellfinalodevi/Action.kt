package com.example.turkcellfinalodevi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class Action : AppCompatActivity() {

    lateinit var txtEmail: TextView
    lateinit var txtPassword: TextView
    lateinit var btnExit: ImageButton


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_action)


        txtEmail = findViewById(R.id.txtEmail)
        txtPassword = findViewById(R.id.txtPassword)
        btnExit = findViewById(R.id.btnExit)


        val email = intent.getStringExtra("email")
        val password = intent.getStringExtra("password")

        if (email != null && password != null) {
            txtEmail.text = email
            txtPassword.text = password
        }

        btnExit.setOnClickListener {

            val shared = getSharedPreferences("users", MODE_PRIVATE)
            val email = shared.getString("email", "")
            val password = shared.getString("password", "")

            val edit = shared.edit()
            edit.remove(email)
            edit.remove(password)
            edit.commit()
            finish()


        }


    }
}
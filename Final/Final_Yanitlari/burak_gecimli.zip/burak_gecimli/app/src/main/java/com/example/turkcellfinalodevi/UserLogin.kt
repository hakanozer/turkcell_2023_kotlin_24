package com.example.turkcellfinalodevi

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class UserLogin : AppCompatActivity() {
    lateinit var txtLoginEmail: EditText
    lateinit var txtLoginPassword: EditText
    lateinit var btnLoginLogin: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_login)

        txtLoginEmail = findViewById(R.id.txtLoginEmail)
        txtLoginPassword = findViewById(R.id.txtLoginPassword)
        btnLoginLogin = findViewById(R.id.btnLoginLogin)



        btnLoginLogin.setOnClickListener {


            val shared = getSharedPreferences("users", MODE_PRIVATE)
            val savedEmail = shared.getString("email", "").toString()
            val savedPassword = shared.getString("password", "").toString()

            var email = txtLoginEmail.text.toString().trim().replace(" ", "")
            var password = txtLoginPassword.text.toString().trim().replace(" ", "")

            if (email == "") {
                Toast.makeText(this, "E-mail Empty!", Toast.LENGTH_LONG).show()
            } else if (password == "") {
                Toast.makeText(this, "Password Empty!", Toast.LENGTH_LONG).show()
            }

            if (savedEmail != email) {
                Toast.makeText(this, "Email failed", Toast.LENGTH_SHORT).show()
            }else if(savedPassword != password) {
                Toast.makeText(this, "Password failed", Toast.LENGTH_SHORT).show()
            }else{
                val intent = Intent(this, Action::class.java)
                intent.putExtra("email", savedEmail)
                intent.putExtra("password", savedPassword)

                startActivity(intent)
                finish()
            }




        }


    }
}
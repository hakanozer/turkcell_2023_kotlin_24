package com.example.finalExam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
// Oguz Fatih Akgemci
class Profile : AppCompatActivity() {
    lateinit var txtUser: TextView
    lateinit var txtMail:TextView
    lateinit var LogoutBtn:ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        val usr = User(getData("name"),getData("surname"),getData("mail"),getData("password"))
        txtUser= findViewById(R.id.txtUser)
        txtMail= findViewById(R.id.txtMail)
        LogoutBtn=findViewById(R.id.LogoutBtn)
        txtUser.setText(usr.Greeting())
        txtMail.setText(usr.Mail)

        LogoutBtn.setOnClickListener(){
            val i = Intent(this,MainActivity::class.java)
            val shared = getSharedPreferences("UserData", MODE_PRIVATE)
            val editor = shared.edit()
            editor.clear()
            editor.commit()
            startActivity(i)
            finish()
        }
    }
    fun getData(str: String):String{
        val shared = getSharedPreferences("UserData", MODE_PRIVATE)
        return shared.getString(str,"").toString()
    }
}
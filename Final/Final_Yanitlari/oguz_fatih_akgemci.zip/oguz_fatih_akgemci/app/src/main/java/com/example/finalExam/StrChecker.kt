package com.example.finalExam

class StrChecker() {
    fun hasSpace(str:String):Boolean{
        for (character in str){
            if(character == ' ')
                return true
        }
        return false
    }
    fun notCorrect(str :String):Boolean{
        return str == "" || hasSpace(str)
    }
}
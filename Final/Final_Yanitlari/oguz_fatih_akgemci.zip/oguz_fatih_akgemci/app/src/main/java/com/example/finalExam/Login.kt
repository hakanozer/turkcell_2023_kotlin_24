package com.example.finalExam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
// Oguz Fatih Akgemci
class Login : AppCompatActivity() {
    lateinit var loginMail:EditText
    lateinit var loginPwd :EditText
    lateinit var loginBtn :ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        loginMail=findViewById(R.id.loginMail)
        loginPwd=findViewById(R.id.loginPwd)
        loginBtn= findViewById(R.id.loginBtn)

        val i = Intent(this,Profile::class.java)
        val usr = User(getData("name"),getData("surname"),getData("mail"),getData("password"))

        loginBtn.setOnClickListener(){
            var mail =loginMail.getText().toString()
            val pwd = loginPwd.getText().toString()
            var authorized = usr.isAuth(mail,pwd)
            if(authorized){
                startActivity(i)
                finish()
            }else{
                val toast = Toast.makeText(this, "Mail ya da Sifre yanlıs.", Toast.LENGTH_LONG)
                toast.show()
            }
        }

    }
    fun getData(str: String):String{
        val shared = getSharedPreferences("UserData", MODE_PRIVATE)
        return shared.getString(str,"").toString()
    }
}
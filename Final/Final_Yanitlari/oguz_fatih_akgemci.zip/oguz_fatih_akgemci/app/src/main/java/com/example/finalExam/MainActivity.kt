package com.example.finalExam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
// Oguz Fatih Akgemci
class MainActivity : AppCompatActivity() {
    lateinit var SinName :EditText
    lateinit var SinSurname :EditText
    lateinit var SinMail :EditText
    lateinit var SinPwd :EditText
    lateinit var signup : ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        SinName = findViewById(R.id.SinName)
        SinSurname = findViewById(R.id.SinSurName)
        SinMail = findViewById(R.id.SinMail)
        SinPwd = findViewById(R.id.SinPassword)
        signup = findViewById(R.id.SinBtn)
        val shared = getSharedPreferences("UserData", MODE_PRIVATE)
        val i = Intent(this,Login::class.java)
        if(shared.getString("name","")==""){
            signup.setOnClickListener(){
                var attemptCorrect = true
                var stchk =StrChecker()
                var name = SinName.getText().toString()
                var surname = SinSurname.getText().toString()
                var mail = SinMail.getText().toString()
                var pwd = SinPwd.getText().toString()
                var text = "Bos veya bosluk dolu giris yaptiniz, Duzeltin:"
                if(stchk.notCorrect(name)){
                    text= text+ " isim, "
                    attemptCorrect=false
                }
                if(stchk.notCorrect(surname)){
                    text= text+ " soyisim, "
                    attemptCorrect=false
                }
                if(stchk.notCorrect(mail)){
                    text= text+ " mail, "
                    attemptCorrect=false
                }
                if(stchk.notCorrect(pwd)){
                    text= text+ " sifre, "
                    attemptCorrect=false
                }

                if (!attemptCorrect){
                    val toast = Toast.makeText(this, text, Toast.LENGTH_LONG) // in Activity
                    toast.show()
                }else{
                    val editor = shared.edit()
                    editor.putString("name",name)
                    editor.putString("surname",surname)
                    editor.putString("mail",mail)
                    editor.putString("password",pwd)
                    editor.commit()
                    startActivity(i)
                    finish()

                }
            }

        }else{
            startActivity(i)
            finish()

        }


    }


}
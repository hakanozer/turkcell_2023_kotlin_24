package com.example.finalExam

class User(name:String,surname:String,mail:String,pwd:String) {
   var Name:String= name
    var Surname :String =surname
    var Mail: String=mail
    var Pwd:String=pwd

    fun Greeting():String{
        return "Sn. $Name $Surname"
    }
    fun CheckPwd(pwd:String):Boolean{
        return pwd==Pwd
    }
    fun isAuth(mail:String,password:String):Boolean{
        return (Mail==mail && Pwd== password)
    }
}
package com.example.ibrahimaltunlufinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView

class LoginScreen : AppCompatActivity() {

    lateinit var txtViewLogin: TextView;
    lateinit var txtLoginMail: EditText;
    lateinit var txtLoginPassword: EditText;
    lateinit var btnLoginLogin: ImageButton;
    var pullData = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_screen)

        txtViewLogin = findViewById(R.id.txtViewLogin)
        txtLoginMail = findViewById(R.id.txtLoginMail)
        txtLoginPassword = findViewById(R.id.txtLoginPassword)
        btnLoginLogin = findViewById(R.id.btnLoginLogin)

        val loginMail = intent.getStringExtra("mail1")
        if (loginMail != null){
            this.pullData = loginMail
        }
        val loginSifre = intent.getStringExtra("sifre1")
        if ( loginSifre != null ){
            this.pullData = loginSifre
        }
        val loginName = intent.getStringExtra("name1")
        if ( loginName != null ){
            this.pullData = loginName
        }
        val loginSurname = intent.getStringExtra("surname1")
        if ( loginSurname != null ){
            this.pullData = loginSurname
        }

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = shared.edit()

        val email4 = shared.getString("mail1", "")
        if (email4.equals(txtLoginMail.text.toString())){
            val i =Intent(this,ProfileScreen::class.java)
            startActivity(i)
        }

        btnLoginLogin.setOnClickListener {
            if (loginMail == txtLoginMail.text.toString() && loginSifre == txtLoginPassword.text.toString() ){
                val intent1 = Intent(this,ProfileScreen::class.java)
                val nameSon = loginName
                intent1.putExtra("name3", nameSon)

                val surnameSon = loginSurname
                intent1.putExtra("surname3", surnameSon)

                val mailSon = loginMail
                intent1.putExtra("mail3", mailSon)
                startActivity(intent1)

            }
            val email4 = loginMail
            editor.putString("email4", email4)
            editor.commit()




        }


    }
}
package com.example.ibrahimaltunlufinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var txtViewRegister: TextView;
    lateinit var txtRegisterAd: EditText;
    lateinit var txtRegisterSoyad: EditText;
    lateinit var txtRegisterMail: EditText;
    lateinit var txtRegisterPassword: EditText;
    lateinit var btnRegisterRegister: ImageButton;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtViewRegister = findViewById(R.id.txtViewRegister)
        txtRegisterAd = findViewById(R.id.txtRegisterAd)
        txtRegisterSoyad = findViewById(R.id.txtRegisterSoyad)
        txtRegisterMail = findViewById(R.id.txtRegisterMail)
        txtRegisterPassword = findViewById(R.id.txtRegisterPassword)
        btnRegisterRegister = findViewById(R.id.btnRegisterRegister)

        btnRegisterRegister.setOnClickListener {
            val ad = txtRegisterAd.text.toString().trim()
            val soyad = txtRegisterSoyad.text.toString().trim()
            val mail = txtRegisterMail.text.toString().trim().replace("","")
            val sifre = txtRegisterPassword.text.toString().trim()

            if (ad == ""){
                Toast.makeText(this,"Lütfen adınızı yazın!", Toast.LENGTH_SHORT).show()
            }else if (soyad == ""){
                Toast.makeText(this,"Lütfen soyadınızı yazın!", Toast.LENGTH_SHORT).show()
            }else if (mail == ""){
                Toast.makeText(this,"Lütfen mailinizi yazın!", Toast.LENGTH_SHORT).show()
            }else if (sifre == ""){
                Toast.makeText(this,"Lütfen şifrenizi yazın", Toast.LENGTH_SHORT).show()
            }else {
                Log.d("ad",ad)
                Log.d("soyad",soyad)
                Log.d("mail",mail)
                Log.d("sifre",sifre)
            }



            val intent = Intent(this,LoginScreen::class.java)


            val registerMail = txtRegisterMail.text.toString()
            intent.putExtra("mail1", registerMail)
            val registerSifre = txtRegisterPassword.text.toString()
            intent.putExtra("sifre1", registerSifre)


            val registerName = txtRegisterPassword.text.toString()
            intent.putExtra("name1", registerName)
            val registerSurname = txtRegisterPassword.text.toString()
            intent.putExtra("surname1", registerSurname)
            startActivity(intent)





        }
    }
}
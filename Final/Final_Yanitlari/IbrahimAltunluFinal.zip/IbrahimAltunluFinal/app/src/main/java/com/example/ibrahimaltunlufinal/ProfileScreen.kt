package com.example.ibrahimaltunlufinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class ProfileScreen : AppCompatActivity() {

    lateinit var txtViewProfile: TextView;
    lateinit var txtSnProfile: EditText;
    lateinit var txtProfileMail: EditText;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_screen)

        txtViewProfile = findViewById(R.id.txtViewProfile)
        txtSnProfile = findViewById(R.id.txtSnProfile)
        txtProfileMail = findViewById(R.id.txtProfileMail)


    }
}
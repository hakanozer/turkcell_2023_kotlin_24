package com.nazlicanterliksiz.turkcellgelecegiyazanlar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var btnSave: ImageButton
    lateinit var txtName: EditText
    lateinit var txtSurname: EditText
    lateinit var txtEmail: EditText
    lateinit var txtPassword: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSave = findViewById(R.id.btnSave)
        txtName = findViewById(R.id.txtName)
        txtSurname= findViewById(R.id.txtSurname)
        txtEmail = findViewById(R.id.txtEmail)
        txtPassword = findViewById(R.id.txtPassword)

        val shared = getSharedPreferences("info", MODE_PRIVATE)
        val editor = shared.edit()

        val name = shared.getString("name", "")
        val surname = shared.getString("surname", "")
        val email = shared.getString("email", "")
        val password = shared.getString("password", "")

        if (name.equals("nazlıcan") &&
            surname.equals("terliksiz") &&
            email.equals("nazlican@gmail.com") &&
            password.equals("1234")){

            goToLogIn()
        }

        //Log.d("email", email!!)

        btnSave.setOnClickListener {
            val name = txtName.text.toString()
            val surname = txtSurname.text.toString()
            val email = txtEmail.text.toString()
            val password = txtPassword.text.toString()

            editor.putString("name", name)
            editor.putString("surname", surname)
            editor.putString("email", email)
            editor.putString("password", password)

            if (name != "" && surname != "" && email != "" && password != "") {
                goToLogIn()
            }else {
                Toast.makeText(this, "Please check for the blanks!", Toast.LENGTH_SHORT).show()
            }

            editor.commit()

        }
    }

    fun goToLogIn(){
        val intent = Intent(this@MainActivity, LogInActivity::class.java)
        startActivity(intent)
    }
}
package com.nazlicanterliksiz.turkcellgelecegiyazanlar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class ViewActivity : AppCompatActivity() {

    lateinit var txtEmailView:TextView
    lateinit var txtNameSurnameView:TextView
    lateinit var exitImageButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        txtEmailView= findViewById(R.id.txtEmailView)
        txtNameSurnameView= findViewById(R.id.txtNameSurnameView)
        exitImageButton = findViewById(R.id.exitImageButton)

        val shared = getSharedPreferences("info", MODE_PRIVATE)
        val email = shared.getString("email", "")
        val name = shared.getString("name", "")
        val surname = shared.getString("surname", "")


        txtNameSurnameView.setText(getNameAndSurname("nazlican","terliksiz"))
        txtEmailView.setText(email)


        exitImageButton.setOnClickListener {
            val editor = shared.edit()
            editor.remove("email")
            editor.remove(getNameAndSurname("nazlican","terliksiz"))
            editor.commit()
            finish()
        }

    }
    fun getNameAndSurname( name: String, surname: String ) : String {
        val joinStrig = "Sn. $name $surname"
        return joinStrig
    }
}
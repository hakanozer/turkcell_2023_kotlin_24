package com.nazlicanterliksiz.turkcellgelecegiyazanlar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class LogInActivity : AppCompatActivity() {

    lateinit var btnLogIn: ImageButton
    lateinit var txtEmailSaved: EditText
    lateinit var txtPasswordSaved: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

        btnLogIn = findViewById(R.id.btnLogIn)
        txtEmailSaved = findViewById(R.id.txtEmailSaved)
        txtPasswordSaved = findViewById(R.id.txtPasswordSaved)

        val shared = getSharedPreferences("info", MODE_PRIVATE)
        val editor = shared.edit()


        val email = shared.getString("email", "")
        val password = shared.getString("password", "")

        if (email.equals("nazlican@gmail.com") && password.equals("1234")){
            goToView()
        }

        //Log.d("email", email!!)

        btnLogIn.setOnClickListener {
            val email = txtEmailSaved.text.toString()
            val password = txtPasswordSaved.text.toString()
            editor.putString("email", email)
            editor.putString("password", password)

            if (email != "" && password != "") {
                goToView()
            }else {
                Toast.makeText(this, "Email or Password Empty!", Toast.LENGTH_SHORT).show()
            }

            editor.commit()

        }
    }
    fun goToView(){
        val intent = Intent(this@LogInActivity, ViewActivity::class.java)
        startActivity(intent)
    }
}
package com.example.kullanckaytvegiriuygulamas

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

class GirisEkranı : AppCompatActivity() {


        lateinit var txtData5 : EditText
        lateinit var txtPassword : EditText
        lateinit var btnInput : ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris_ekran)

        txtData5 = findViewById(R.id.txtData5)
        txtPassword = findViewById(R.id.txtPassword)
        btnInput = findViewById(R.id.btnInput)

        btnInput.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtData5.text.toString()
            intent.putExtra("key5", txt)
            startActivity(intent)
        }

        btnInput.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtPassword.text.toString()
            intent.putExtra("key6", txt)
            startActivity(intent)
        }


    }




}
package com.example.kullanckaytvegiriuygulamas

class Profile {
}
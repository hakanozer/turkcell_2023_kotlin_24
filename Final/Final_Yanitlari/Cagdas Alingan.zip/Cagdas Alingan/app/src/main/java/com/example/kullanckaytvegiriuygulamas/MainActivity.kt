package com.example.kullanckaytvegiriuygulamas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    lateinit var txtData : EditText
    lateinit var txtData2 : EditText
    lateinit var txtData3 : EditText
    lateinit var txtData4 : EditText
    lateinit var btnRegister : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtData = findViewById(R.id.txtData)
        txtData2 = findViewById(R.id.txtData2)
        txtData3 = findViewById(R.id.txtData3)
        txtData4 = findViewById(R.id.txtData4)
        btnRegister = findViewById(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtData.text.toString()
            intent.putExtra("key1", txt )
            startActivity(intent)
        }

        btnRegister.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtData2.text.toString()
            intent.putExtra("key2", txt )
            startActivity(intent)
        }
        btnRegister.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtData3.text.toString()
            intent.putExtra("key3", txt )
            startActivity(intent)
        }
        btnRegister.setOnClickListener {
            val intent = Intent(this, GirisEkranı::class.java)
            val txt = txtData4.text.toString()
            intent.putExtra("key4", txt )
            startActivity(intent)
        }


    }
}
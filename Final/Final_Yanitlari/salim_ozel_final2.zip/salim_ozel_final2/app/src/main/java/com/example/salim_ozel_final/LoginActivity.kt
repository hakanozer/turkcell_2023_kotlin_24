package com.example.salim_ozel_final

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton

class LoginActivity : AppCompatActivity() {
    private lateinit var  txtLoginMail : EditText
    private lateinit var  txtLoginPassword : EditText
    private lateinit var btnGiris: ImageButton
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        sharedPreferences = getSharedPreferences("user", MODE_PRIVATE)


        txtLoginMail = findViewById<EditText>(R.id.txtLoginMail)
        txtLoginPassword = findViewById<EditText>(R.id.txtLoginPassword)
        btnGiris = findViewById<ImageButton>(R.id.btnGiris)


        btnGiris.setOnClickListener {
            val loginMail = txtLoginMail.text.toString().trim()
            val loginPassword = txtLoginPassword.text.toString().trim()
            val email = sharedPreferences.getString("mail", "")
            val password = sharedPreferences.getString("password", "")
            if ( loginMail.equals(email)&& loginPassword.equals(password)){
                val i = Intent(this, ProfileActivity::class.java )
                intent.putExtra("mail",loginMail )
                intent.putExtra("mail",sharedPreferences.getString("name","") )

                startActivity(i)
            }
            else {
                print("parola veya şifreniz hatalı lütfen kontrol ediniz ")
            }
        }

    }
}
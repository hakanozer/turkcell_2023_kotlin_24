package com.example.salim_ozel_final

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var  txtName : EditText
    private lateinit var  txtSurname : EditText
    private lateinit var txtMail: EditText
    private lateinit var  txtPassword : EditText
    private lateinit var btnKayitOl: ImageButton
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor


    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        txtName = findViewById<EditText>(R.id.txtName)
        txtSurname = findViewById<EditText>(R.id.txtSurname)
        txtMail = findViewById<EditText>(R.id.txtMail)
        txtPassword = findViewById<EditText>(R.id.txtPassword)
        btnKayitOl = findViewById<ImageButton>(R.id.btnGiris)

        sharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
        editor = sharedPreferences.edit()

        btnKayitOl.setOnClickListener{
            val name = txtName.text.toString().trim()
            val surname = txtSurname.text.toString().trim()
            val mail = txtMail.text.toString().trim()
            val password = txtPassword.text.toString().trim()

            if (name == "" ) {
                Toast.makeText(this@MainActivity, "Name Empty!", Toast.LENGTH_SHORT).show()
            }
            else if ( surname == "" ) {
                Toast.makeText(this@MainActivity, "Surmame Empty!", Toast.LENGTH_SHORT).show()
            }
            else if ( mail == "" ) {
            Toast.makeText(this@MainActivity, "E-Mail Empty!", Toast.LENGTH_SHORT).show()
            }
            else if ( password == "" ) {
            Toast.makeText(this@MainActivity, "Password Empty!", Toast.LENGTH_SHORT).show()
            }
            else{
                val intent = Intent(this, LoginActivity::class.java)
                editor.putString("name", name)
                editor.putString("surname", surname)
                editor.putString("mail", mail)
                editor.putString("password", password)
                editor.commit()
                startActivity(intent)
                Toast.makeText(this, "Kayıt Başarılı!", Toast.LENGTH_SHORT).show()




            }
        }




    }
}
package com.example.sinav

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputBinding
import android.widget.Button

class MainGirisYap : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_giris_yap)


        val button = findViewById<Button>(R.id.btnGirisButton)
        button.setOnClickListener {

            val intent = Intent(this, MainHosGeldiniz::class.java)
            startActivity(intent)
        }
    }}
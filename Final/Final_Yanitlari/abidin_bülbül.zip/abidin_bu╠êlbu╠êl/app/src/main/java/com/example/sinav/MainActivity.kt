package com.example.sinav

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var binding:Activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

       lateinit var etFirstName: EditText
         lateinit var etLastName: EditText
         lateinit var etEmail: EditText
         lateinit var etPassword: EditText
         lateinit var btnRegister: Button
         lateinit var btnLogin: Button


        fun onCreate(savedInstanceState: Bundle?) {


            setContentView(R.layout.activity_main)

            etFirstName = findViewById(R.id.txtKayitKullaniciAdi)
            etLastName = findViewById(R.id.txtKayitKullaniciSoyadi)
            etEmail = findViewById(R.id.txtKayitKullaniciMail)
            etPassword = findViewById(R.id.txtKayitKullaniciSifre)
            btnRegister = findViewById(R.id.btnKayitButton)




            btnRegister.setOnClickListener {
                val firstName = etFirstName.text.toString()
                val lastName = etLastName.text.toString()
                val email = etEmail.text.toString()
                val password = etPassword.text.toString()


                val button = findViewById<Button>(R.id.btnKayitButton)
                button.setOnClickListener {

                    val intent = Intent(this, MainGirisYap::class.java)
                    startActivity(intent)
                }


            }
        }}}
package com.example.sinav

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainHosGeldiniz : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_hos_geldiniz)

        val button=findViewById<Button>(R.id.btnCikisYap)
        button.setOnClickListener{

            val intent= Intent(this,MainActivity::class.java)
            startActivity(intent)
    }
}}
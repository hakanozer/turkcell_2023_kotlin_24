package tr.msguzel.mehmet_serkan_guzel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {
    private lateinit var textName: TextView
    private lateinit var textEmail: TextView
    private lateinit var exitButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        textName = findViewById(R.id.textViewNameProfile)
        textEmail = findViewById(R.id.textViewMailProfile)
        exitButton = findViewById(R.id.exitButton)
        val shared = getSharedPreferences(SharedPrefManager.file_name, MODE_PRIVATE)
        val editor = shared.edit()
        val sharedPrefName = shared.getString(SharedPrefManager.name, "")
        val sharedPrefSurname = shared.getString(SharedPrefManager.surname, "")
        val sharedPrefEmail = shared.getString(SharedPrefManager.email, "")
        textName.text = "Sn. $sharedPrefName $sharedPrefSurname"
        textEmail.text = sharedPrefEmail

        exitButton.setOnClickListener {
            editor.clear()
            editor.apply()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

    }
}
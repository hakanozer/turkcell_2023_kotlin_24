package tr.msguzel.mehmet_serkan_guzel

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {
    private lateinit var editTextName: EditText
    private lateinit var editTextSurname: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var signUpButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        editTextName = findViewById(R.id.editTextName)
        editTextSurname = findViewById(R.id.editTextSurname)
        editTextEmail = findViewById(R.id.editTextEmail)
        editTextPassword = findViewById(R.id.editTextPassword)
        signUpButton = findViewById(R.id.sign_up_button)
        val preferences = getSharedPreferences(SharedPrefManager.file_name, MODE_PRIVATE)
        val editor = preferences.edit()

        signUpButton.setOnClickListener {
            if(isAuthOK()){
                saveSharedPreferences(editor,SharedPrefManager.name,editTextName.text.toString())
                saveSharedPreferences(editor,SharedPrefManager.surname,editTextSurname.text.toString())
                saveSharedPreferences(editor,SharedPrefManager.email,editTextEmail.text.toString())
                saveSharedPreferences(editor,SharedPrefManager.password,editTextPassword.text.toString())
                editor.apply()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }else{
                val toast = Toast.makeText(applicationContext, "Lütfen eksik bilgileri giriniz", Toast.LENGTH_LONG)
                toast.show()
            }
        }
    }

    private fun isAuthOK() : Boolean = ValidationManager.isValidName(editTextName.text.toString()) &&
            ValidationManager.isValidSurname(editTextSurname.text.toString()) &&
            ValidationManager.isValidEmail(editTextEmail.text.toString()) &&
            ValidationManager.isValidPassword(editTextPassword.text.toString())

    private fun saveSharedPreferences(editor: SharedPreferences.Editor,key:String,value:String){
        editor.putString(key,value)
    }
}
package tr.msguzel.mehmet_serkan_guzel

class SharedPrefManager {

    companion object{
        const val file_name = "users"
        const val name = "name"
        const val surname = "surname"
        const val email = "email"
        const val password = "password"

    }
}
package tr.msguzel.mehmet_serkan_guzel

import java.util.regex.Pattern

class ValidationManager {
    companion object{
         private val emailAddressPattern: Pattern = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
        )
         fun isValidName(name:String) : Boolean{
            return name.trim() != ""
        }
         fun isValidSurname(surname:String) : Boolean{
            return surname.trim() != ""
        }
         fun isValidEmail(email:String) : Boolean{
            return email.trim() != "" && emailAddressPattern.matcher(email).matches();

        }
         fun isValidPassword(password:String) : Boolean{
            return password.trim() != ""
        }
    }
}
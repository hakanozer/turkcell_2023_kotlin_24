package tr.msguzel.mehmet_serkan_guzel

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    private lateinit var editTextEmail: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var loginButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        editTextEmail = findViewById(R.id.editTextEmailLogin)
        editTextPassword = findViewById(R.id.editTextPasswordLogin)
        loginButton = findViewById(R.id.buttonLogin)
        val shared = getSharedPreferences(SharedPrefManager.file_name, MODE_PRIVATE)
        val sharedPrefEmail = shared.getString(SharedPrefManager.email, "")
        val sharedPrefPassword = shared.getString(SharedPrefManager.password, "")
        loginButton.setOnClickListener{
            if(isAuthOK(editTextEmail.text.toString(), editTextPassword.text.toString(), sharedPrefEmail, sharedPrefPassword)){
                val intent = Intent(this, ProfileActivity::class.java)
                startActivity(intent)
                finish()
            }else{
                val toast = Toast.makeText(applicationContext, "Kullanıcı Bulunamadı", Toast.LENGTH_LONG)
                toast.show()
            }
        }
    }

    private fun isAuthOK(email:String,password:String,sharedPrefEmail:String?,sharedPrefPassword:String?) : Boolean {
        return email == sharedPrefEmail && password == sharedPrefPassword
    }
}
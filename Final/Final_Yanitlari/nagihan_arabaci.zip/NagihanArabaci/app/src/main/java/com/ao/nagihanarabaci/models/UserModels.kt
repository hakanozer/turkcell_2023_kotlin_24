package com.ao.nagihanarabaci.models

data class UserModels(
    var name: String?,
    var surName: String?,
    var email: String?,
    var password: String?
)
package com.ao.nagihanarabaci.services

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.ao.nagihanarabaci.models.UserModels


class SharedPrefs(context: Context) {
    private val sharedPrefs: SharedPreferences =
        context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPrefs.edit()


    fun writeUserListData(key: String, value: UserModels) {
        val set = mutableSetOf<String>()
        set.add("${value.name},${value.surName},${value.email},${value.password}")
        editor.putStringSet(key, set)
        editor.apply()
    }

    fun readUserListData(key: String): List<UserModels> {
        val set = sharedPrefs.getStringSet(key, mutableSetOf()) ?: mutableSetOf()
        val list = mutableListOf<UserModels>()
        set.forEach {
            val user = UserModels( name = null, surName = null, email = null, password = null )
            val data = it.split(",")
            user.name = data[0]
            user.surName = data[1]
            user.email = data[2]
            user.password = data[3]
            list.add(user)
        }
        return list
    }

    fun writeActiveUser(value: UserModels) {
        editor.putString("activeUser", "${value.name},${value.surName},${value.email},${value.password}")
        editor.apply()
    }

    fun readActiveUser(): UserModels {
        val data = sharedPrefs.getString("activeUser", null)?.split(",") ?: listOf()
        val user = UserModels( name = null, surName = null, email = null, password = null )
        user.name = data[0]
        user.surName = data[1]
        user.email = data[2]
        user.password = data[3]
        return user
    }

    fun clearActiveUser() {
        editor.remove("activeUser")
        editor.apply()
    }

    fun deleteData(key: String) {
        editor.remove(key)
        editor.apply()
    }
}
package com.ao.nagihanarabaci

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.ao.nagihanarabaci.models.UserModels
import com.ao.nagihanarabaci.services.SharedPrefs

class LoginView : AppCompatActivity() {
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var loginButton: ImageButton
    private lateinit var registerButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_view)
        initialized()
    }

    private fun initialized() {
        emailField = findViewById(R.id.emailEditText)
        passwordField = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.registerButton)
        registerButton = findViewById(R.id.loginButton)
        login()
        registerNavigation()
    }


    private fun login() {
        loginButton.setOnClickListener {
            val email = emailField.text.toString()
            val password = passwordField.text.toString()
            if (inputValidation(email = email, password = password)) {
                val prefs = SharedPrefs(this)
                val userList = prefs.readUserListData("userList")
                val isLogin =
                    userList.filter { it.email?.trim() == email.trim() && it.password?.trim() == password.trim() }

                if (isLogin.isNotEmpty())
                    prefs.writeActiveUser(isLogin.first())
                Toast.makeText(this, "Giriş başarılı!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeView::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(
                    this,
                    "Giriş başarısız!\nLütfen bilgilerinizi kontrol ediniz!",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    private fun registerNavigation() {
        registerButton.setOnClickListener {
            val intent = Intent(this, RegisterView::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun inputValidation(email: String, password: String): Boolean {
        if (email.trim().contains("@").not()) {
            Toast.makeText(this, "Lütfen geçerli bir mail adresi giriniz!", Toast.LENGTH_SHORT)
                .show()
            return false
        }
        if (password.trim().isEmpty()) {
            Toast.makeText(this, "Lütfen geçerli bir şifre giriniz!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
}
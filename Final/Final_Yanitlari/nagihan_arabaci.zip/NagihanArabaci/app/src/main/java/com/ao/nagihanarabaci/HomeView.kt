package com.ao.nagihanarabaci

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.TextView
import com.ao.nagihanarabaci.services.SharedPrefs

class HomeView : AppCompatActivity() {
    private lateinit var userNameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var exitButton: ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_view)
        initialized()
    }

    private fun initialized() {
        userNameTextView = findViewById(R.id.userName)
        emailTextView = findViewById(R.id.userMail)
        exitButton = findViewById(R.id.exitButton)
        getUserData()
        exit()
    }

    private fun getUserData() {
        val prefs = SharedPrefs(this)
        val user = prefs.readActiveUser()
        userNameTextView.text = "Sn. ${user.name} ${user.surName}"
        emailTextView.text = user.email
    }

    private fun exit() {
        exitButton.setOnClickListener {
            val prefs = SharedPrefs(this)
            /*
            * Hocam Ben bir user listesi oluşturdum ve bu listeye kayır olan tüm kullanıcıları ekledim
            * Birde aktif kullanıcı kaydettim, giriş yapılınca aktif kullanıcı giriş yapan kullanıcı oluyor
            * Daha sonra burda çıkış yaparken user listesindeki kullanıcı bilgisini değil, kaydettiğim aktif kullanıcı bilgisini temizledim
            * Yani kullanıcı çıkış yaptığında tekrar giriş yapması için yaptım bunu.
            */
            prefs.clearActiveUser()
            val intent = Intent(this, RegisterView::class.java)
            startActivity(intent)
            finish()
        }
    }
}
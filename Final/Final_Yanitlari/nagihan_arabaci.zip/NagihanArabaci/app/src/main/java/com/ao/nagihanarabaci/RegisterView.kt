package com.ao.nagihanarabaci

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import com.ao.nagihanarabaci.models.UserModels
import com.ao.nagihanarabaci.services.SharedPrefs

class RegisterView : AppCompatActivity() {

    private lateinit var nameField: EditText
    private lateinit var surNameField: EditText
    private lateinit var emailField: EditText
    private lateinit var passwordField: EditText
    private lateinit var loginButton: ImageButton
    private lateinit var registerButton: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_view)
        initialized()
    }

    private fun initialized() {
        nameField = findViewById(R.id.nameEditText)
        surNameField = findViewById(R.id.surNameEditText)
        emailField = findViewById(R.id.emailEditText)
        passwordField = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        registerButton = findViewById(R.id.registerButton)
        register()
        loginNavigation()
    }

    private fun register() {
        registerButton.setOnClickListener {
            val name = nameField.text.toString()
            val surname = surNameField.text.toString()
            val email = emailField.text.toString()
            val password = passwordField.text.toString()
            if (inputValidation(
                    name = name, surname = surname, email = email, password = password
                )
            ) {
                val prefs = SharedPrefs(this)
                val userList = prefs.readUserListData("userList")
                val isLogin: Boolean =
                    userList.filter { it.email == email && it.password == password }.isNotEmpty()
                if (isLogin.not()) {
                    prefs.writeUserListData(
                        "userList",
                        UserModels(
                            name = name, surName = surname, email = email, password = password
                        )
                    )
                    Toast.makeText(this, "Kayıt başarılı!", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, LoginView::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    Toast.makeText(this, "Bu e-mail ile daha önce kayıt olundu", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
    }

    private fun loginNavigation() {
        loginButton.setOnClickListener {
            val intent = Intent(this, LoginView::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun inputValidation(
        name: String, surname: String, email: String, password: String
    ): Boolean {
        if (name.trim().isEmpty() || surname.trim().isEmpty()) {
            Toast.makeText(this, "Lütfen geçerli bir İsim-Soyisim giriniz!", Toast.LENGTH_SHORT)
                .show()
            return false
        }
        if (email.trim().contains("@").not()) {
            Toast.makeText(this, "Lütfen geçerli bir mail adresi giriniz!", Toast.LENGTH_SHORT)
                .show()
            return false
        }
        if (password.trim().isEmpty()) {
            Toast.makeText(this, "Lütfen geçerli bir şifre giriniz!", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
}
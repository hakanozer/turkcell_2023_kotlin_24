package com.example.yigit_dulkadir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var btnSave: Button
    lateinit var txtAd: EditText
    lateinit var txtSoyAd: EditText
    lateinit var txtMail: EditText
    lateinit var txtSifre: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = shared.edit()

        txtAd = findViewById(R.id.txtAd)
        btnSave = findViewById(R.id.btnSave)
        txtMail = findViewById(R.id.txtMail)
        txtSoyAd = findViewById(R.id.txtSoyad)
         txtSifre=findViewById(R.id.txtSifre)
        btnSave.setOnClickListener {
            val ad = txtAd.text.toString()
            editor.putString("ad", ad)
            val soyad = txtSoyAd.text.toString()
            editor.putString("soyad", soyad)
            val mail = txtMail.text.toString()
           editor.putString("mail", mail)
            val sifre=txtSifre.text.toString()
            editor.putString("sifre",sifre)

            editor.commit()

            Toast.makeText(this@MainActivity, "kayıt başarılı oldu ", Toast.LENGTH_LONG).show()


        }
        val button = findViewById<Button>(R.id.btnSave)
        button.setOnClickListener()
        {

            if(txtAd.toString()==""){
                Toast.makeText(this@MainActivity,"boş",Toast.LENGTH_SHORT).show()
            }

            else if(txtMail.toString()==""){
                Toast.makeText(this@MainActivity,"boş",Toast.LENGTH_SHORT).show()
            }
            else if(txtSoyAd.toString()==""){
                Toast.makeText(this@MainActivity,"boş",Toast.LENGTH_SHORT).show()
            }
            else if(txtSifre.toString()==""){
                Toast.makeText(this@MainActivity,"boş",Toast.LENGTH_SHORT).show()
            }


            else {


                val intent = Intent(this@MainActivity, giris::class.java)
                startActivity(intent)
                Toast.makeText(this@MainActivity, "kayıt başarılı oldu ", Toast.LENGTH_LONG).show()


            }
                }


            }
        }



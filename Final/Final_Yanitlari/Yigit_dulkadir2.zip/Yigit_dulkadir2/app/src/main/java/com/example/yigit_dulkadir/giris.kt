package com.example.yigit_dulkadir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class giris : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_giris)

        val shared= getSharedPreferences( "users" , MODE_PRIVATE)
        val editor=shared.edit()

        val email =shared.getString("email","")
        val sifre =shared.getString("sifre","")

        if(email.equals("mail")&& sifre.equals("sifre")){
            val i =Intent(this@giris, profil::class.java)
            startActivity(i)




        }


        val button = findViewById<Button>(R.id.goprofile)
        button.setOnClickListener()
        {
            val intent = Intent(this@giris, profil::class.java)
            startActivity(intent)
            Toast.makeText(this@giris, "profil ekranına yönlendiriliyosunuz  ", Toast.LENGTH_LONG).show()
        }


    }
}
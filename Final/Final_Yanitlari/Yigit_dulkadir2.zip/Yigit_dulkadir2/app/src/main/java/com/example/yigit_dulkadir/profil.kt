package com.example.yigit_dulkadir

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast

class profil : AppCompatActivity() {
    lateinit var btnExit:ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        btnExit=findViewById(R.id.btnExit)





        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val mail=shared.getString("mail","")


        btnExit.setOnClickListener {
            val edit=shared.edit()
            edit.clear()
            edit.commit()



        }


        btnExit.setOnClickListener()
        {
            val intent= Intent(this@profil,MainActivity::class.java)
            startActivity(intent)

        }









    }
}
package com.bilalkamalak.bilalkamalakfinal

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ProfileActivity : AppCompatActivity() {
     lateinit var textViewMail: TextView
     lateinit var textViewSifre: TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        textViewMail = findViewById(R.id.textView)
        textViewSifre = findViewById(R.id.textView2)





    }
}
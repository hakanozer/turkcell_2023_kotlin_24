package com.bilalkamalak.bilalkamalakfinal

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    lateinit var editText1: EditText
    lateinit var editText2: EditText
    lateinit var editText3: EditText
    lateinit var editText4: EditText
    lateinit var button: Button
    private lateinit var sharedPreferences:SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText1 = findViewById(R.id.editText1)
        editText2 = findViewById(R.id.editText2)
        editText3 = findViewById(R.id.editText3)
        editText4 = findViewById(R.id.editText4)
        button = findViewById(R.id.button)
        sharedPreferences = getSharedPreferences("Pref", MODE_PRIVATE)
        val editor = sharedPreferences.edit()


        button.setOnClickListener {
            val adi = editText1.text.toString()
            val soyadi = editText2.text.toString()
            val mail = editText3.text.toString()
            val sifre = editText4.text.toString()
            val editor = sharedPreferences.edit()
            editor.putString("Adi", adi)
            editor.putString("Soyadi", soyadi)
            editor.putString("Mail", mail)
            editor.putString("Sifre", sifre)
            editor.apply()
            Toast.makeText(this@MainActivity, "Giriş Başarılı", Toast.LENGTH_LONG).show()
        }
    } val intent = Intent(this@MainActivity, Profile::class.java)
    // start komutunu koymama rağmen kabul etmiyor


}


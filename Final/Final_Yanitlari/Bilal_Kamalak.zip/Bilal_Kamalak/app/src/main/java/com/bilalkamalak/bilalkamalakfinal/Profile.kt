package com.bilalkamalak.bilalkamalakfinal

import android.content.SharedPreferences
import android.net.MailTo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Profile  : AppCompatActivity() {
    lateinit var editText5:EditText
    lateinit var editText6:EditText
    lateinit var button2: Button
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        editText5 = findViewById(R.id.editText5)
        editText6 = findViewById(R.id.editText6)
        button2 = findViewById(R.id.button2)
        sharedPreferences = getSharedPreferences("Pref", MODE_PRIVATE)
        button2.setOnClickListener {
            val mail = editText5.text.toString()  // to.Intornull tanımlamamız gerekmiyor mu hocam?
            val sifre = editText6.text.toString()
            val editor = sharedPreferences.edit()
            editor.putString("Mail", mail )
            editor.putString("Sifre",sifre)
            Toast.makeText(this@Profile, "Giriş Bilgisi Alındı", Toast.LENGTH_SHORT).show()

        }


    }
}
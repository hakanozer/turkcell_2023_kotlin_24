package com.example.finalodevi

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import org.w3c.dom.Text


class MainActivity : AppCompatActivity() {

    lateinit var shared: SharedPreferences
    lateinit var editor: SharedPreferences.Editor

    lateinit var txtName: EditText
    lateinit var txtSurname: EditText
    lateinit var txtEmail: EditText
    lateinit var txtPassword: EditText
    lateinit var btnRegister: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        shared = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        editor = shared.edit()

        txtName = findViewById(R.id.txtName)
        txtSurname = findViewById(R.id.txtSurname)
        txtEmail = findViewById(R.id.txtEmail)
        txtPassword = findViewById(R.id.txtPassword)
        btnRegister = findViewById(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val name = txtName.text.toString().trim()
            val surname = txtSurname.text.toString().trim()
            val email = txtEmail.text.toString().trim()
            val pass = txtPassword.text.toString().trim()


            if (name.isEmpty() || surname.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurun", Toast.LENGTH_SHORT).show()
            } else {
                editor.putString("name", name)
                editor.putString("surname", surname)
                editor.putString("email", email)
                editor.putString("password", pass)
                editor.apply()

                val i = Intent(this, LoginActivity::class.java)
                startActivity(i)
                finish()

            }
        }
    }
}



package com.yusufatakanozmen.finalodev

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginPage : AppCompatActivity() {
    lateinit var txtKullanici:TextView
    lateinit var txtEmailGiris:EditText
    lateinit var txtSifreGiris:EditText
    lateinit var btnGiris:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        txtEmailGiris = findViewById(R.id.txtEmailGiris)
        txtSifreGiris = findViewById(R.id.txtSifreGiris)
        btnGiris = findViewById(R.id.btnGiris)

        //sharedPreferences ile kayıtlı kullanıcı bilgilerini alıyoruz.
        val Shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = Shared.edit()
        val email = Shared.getString("Email", "")
        val sifre = Shared.getString("Sifre", "")

        //Giriş butonuna tıklandığında girilen bilgileri kontrol ediyoruz.
        btnGiris.setOnClickListener {
            val emailGiris = txtEmailGiris.text.toString()
            val sifreGiris = txtSifreGiris.text.toString()

            //Eğer girilen bilgiler boş ise uyarı veriyoruz.
            if (emailGiris.isEmpty() || sifreGiris.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurunuz.", Toast.LENGTH_SHORT).show()
            }
            //Eğer girilen bilgiler kayıtlı bilgiler ile eşleşiyorsa giriş yapılıyor.profil sayfasına yönlendiriliyor.
            else if (emailGiris == email && sifreGiris == sifre) {
                val i = Intent(this, Profile::class.java)
                startActivity(i)
            } else {
                Toast.makeText(this, "Hatalı Giriş", Toast.LENGTH_SHORT).show()
            }
        }


    }
}
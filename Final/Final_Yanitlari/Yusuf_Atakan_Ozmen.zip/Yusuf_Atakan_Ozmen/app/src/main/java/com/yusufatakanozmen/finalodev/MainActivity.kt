package com.yusufatakanozmen.finalodev

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    // onCreate fonksiyonu uygulama açıldığında çalışan fonksiyondur.
    lateinit var txtKullanici:TextView
    lateinit var txtAdi:EditText
    lateinit var txtSoyadi:EditText
    lateinit var txtEmail: EditText
    lateinit var txtSifre:EditText
    lateinit var btnKayit: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val Shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = Shared.edit()


        txtAdi = findViewById(R.id.txtAdi)
        txtSoyadi = findViewById(R.id.txtSoyadi)
        txtEmail = findViewById(R.id.txtEmail)
        txtSifre = findViewById(R.id.txtSifre)
        btnKayit = findViewById(R.id.btnKayit)

        btnKayit.setOnClickListener {
            val adi = txtAdi.text.toString()
            val soyadi = txtSoyadi.text.toString()
            val email = txtEmail.text.toString()
            val sifre = txtSifre.text.toString()

            if (adi.isEmpty() || soyadi.isEmpty() || email.isEmpty() || sifre.isEmpty()) {
                Toast.makeText(this, "Lütfen tüm alanları doldurunuz.", Toast.LENGTH_SHORT).show()
            } else {
                editor.putString("Adi", adi)
                editor.putString("Soyadi", soyadi)
                editor.putString("Email", email)
                editor.putString("Sifre", sifre)
                editor.commit()
                Toast.makeText(this, "Kayıt Başarılı", Toast.LENGTH_SHORT).show()
                val i= Intent(this, LoginPage::class.java)
                startActivity(i)
            }
        }

    }
}
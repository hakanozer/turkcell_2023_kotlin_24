package com.yusufatakanozmen.finalodev

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Profile : AppCompatActivity() {

    lateinit var textViewHos:TextView
    lateinit var textViewAdi:TextView
    lateinit var textViewMail:TextView
    lateinit var btnCikis:Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        textViewHos = findViewById(R.id.textViewHos)
        textViewAdi = findViewById(R.id.textViewAdi)
        textViewMail = findViewById(R.id.textViewMail)
        btnCikis = findViewById(R.id.btnCikis)

        val Shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = Shared.edit()
        val adi = Shared.getString("Adi", "")
        val email = Shared.getString("Email", "")

        textViewAdi.text = adi
        textViewMail.text = email

        //Çıkış butonuna tıklandığında sharedPreferences içerisindeki tüm verileri silip uygulamadan çıkış yapar.
            btnCikis.setOnClickListener {
            editor.clear()
            editor.commit()
            finish()

        }

    }
}
package com.example.volkankelleciturkcell

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.volkankelleciturkcell.databinding.FragmentLoginBinding


class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding?=null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.loginButton.setOnClickListener {
            val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            val email = sharedPreferences.getString("email", "")
            val password = sharedPreferences.getString("password", "")

            val emailInput=binding.editTextEmail.text.toString()
            val passwordInput=binding.editTextPassword.text.toString()


            if (emailInput.equals(email)&&passwordInput.equals(password)&&emailInput.isNotEmpty()&&passwordInput.isNotEmpty()){
                val action=LoginFragmentDirections.actionLoginFragmentToProfileFragment()
                findNavController().navigate(action)
            }else{
                Toast.makeText(activity, "Please fill all information", Toast.LENGTH_SHORT).show()
        }

        }
        binding.signinButton.setOnClickListener {
            val action2=LoginFragmentDirections.actionLoginFragmentToRegistirationFragment()
            findNavController().navigate(action2)
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}
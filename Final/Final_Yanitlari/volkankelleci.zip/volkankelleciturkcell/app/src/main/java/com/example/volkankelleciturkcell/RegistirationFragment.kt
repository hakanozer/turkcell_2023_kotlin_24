package com.example.volkankelleciturkcell

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.volkankelleciturkcell.databinding.ActivityMainBinding
import com.example.volkankelleciturkcell.databinding.FragmentRegistirationBinding


class RegistirationFragment : Fragment() {
    private var _binding: FragmentRegistirationBinding?=null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding=FragmentRegistirationBinding.inflate(inflater,container,false)
        val view=binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.registerButton.setOnClickListener {

            val name=binding.editTextName.text.toString().trim()
            val surname=binding.editTextSurname.text.toString().trim()
            val mail=binding.editTextEmail.text.toString().trim()
            val password=binding.editTextPassword.text.toString().trim()
            
            if(name.isNotEmpty()&&surname.isNotEmpty()&&mail.isNotEmpty()&&password.isNotEmpty()){
                val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                editor.putString("name", name)
                editor.putString("surname", surname)
                editor.putString("email", mail)
                editor.putString("password", password)
                editor.apply()

                val action=RegistirationFragmentDirections.actionRegistirationFragmentToLoginFragment()
                findNavController().navigate(action)

            }
            else{
                Toast.makeText(activity, "Please fill all information trustly", Toast.LENGTH_SHORT).show()
                
            }
    }


}
}
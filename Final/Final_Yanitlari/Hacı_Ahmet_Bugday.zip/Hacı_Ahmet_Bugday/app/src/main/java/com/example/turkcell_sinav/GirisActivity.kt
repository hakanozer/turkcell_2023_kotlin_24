package com.example.turkcell_sinav

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class GirisActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    private lateinit var txtEmail: EditText
    private lateinit var txtSifre: EditText
    private lateinit var btnGiris: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kullanici_giris)

        sharedPreferences = getSharedPreferences("users", MODE_PRIVATE)
        editor = sharedPreferences.edit()

        txtEmail = findViewById(R.id.GirisMailEditText)
        txtSifre = findViewById(R.id.GirisSifreEditText)
        btnGiris = findViewById(R.id.GirisBtn)

        btnGiris.setOnClickListener {

            val email = txtEmail.text.toString()
            val sifre = txtSifre.text.toString()

            if (email.equals("") || sifre.equals(""))
            {
                showToast("Tüm alanları Doldur")
            }
            else
            {
                val saveEmail = sharedPreferences.getString("email","")
                val saveSifre = sharedPreferences.getString("sifre","")

                if (email == saveEmail && sifre == saveSifre)
                {
                    ProfileGit()
                }
                else
                {
                    showToast("Geçersiz email veya şifre")
                }
            }
        }
    }
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun ProfileGit()
    {
        val intent = Intent(this, ProfilActivity::class.java)
        startActivity(intent)
    }
}
package com.example.turkcell_sinav

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView

class ProfilActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor


    private lateinit var btnCikis: ImageButton
    private lateinit var tvHosgeldin: TextView
    private lateinit var tvAdSoyad: TextView
    private lateinit var tvMail: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)


        sharedPreferences = getSharedPreferences("users", MODE_PRIVATE)
        editor = sharedPreferences.edit()

        btnCikis = findViewById(R.id.ProfilCikisButon)
        tvHosgeldin = findViewById(R.id.ProfilHosgldnzTxt)
        tvAdSoyad = findViewById(R.id.ProfilSnTxt)
        tvMail = findViewById(R.id.ProfilMailTxt)

        val ad = sharedPreferences.getString("ad", "")
        val soyad = sharedPreferences.getString("soyad", "")
        val email = sharedPreferences.getString("email", "")

        tvHosgeldin.text = "Hoş Geldiniz"
        tvAdSoyad.text = "Sn.$ad $soyad"
        tvMail.text = email

        btnCikis.setOnClickListener {
            editor.clear()
            editor.apply()

            kayitEkraninaGit()
        }

    }
    private fun kayitEkraninaGit() {
        val intent = Intent(this, KayitActivity::class.java)
        startActivity(intent)
        finish()
    }

}
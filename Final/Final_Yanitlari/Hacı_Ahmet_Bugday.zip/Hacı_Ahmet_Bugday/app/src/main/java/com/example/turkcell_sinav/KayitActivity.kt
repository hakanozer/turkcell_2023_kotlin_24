package com.example.turkcell_sinav


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast



class KayitActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    private lateinit var txtAd: EditText
    private lateinit var txtSoyAd: EditText
    private lateinit var txtEmail: EditText
    private lateinit var txtSifre: EditText
    private lateinit var btnKayit: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kullanici_kayit)

        sharedPreferences = getSharedPreferences("users", MODE_PRIVATE)
        editor = sharedPreferences.edit()

        txtAd = findViewById(R.id.KayitAdiEditText)
        txtSoyAd = findViewById(R.id.KayitSoyadiEditText)
        txtEmail = findViewById(R.id.KayitMailEditText)
        txtSifre = findViewById(R.id.KayitSifreEditText)
        btnKayit = findViewById(R.id.KayitkayitOlbtn)

        btnKayit.setOnClickListener {
            val ad = txtAd.text.toString()
            val soyad = txtSoyAd.text.toString()
            val email = txtEmail.text.toString()
            val sifre = txtSifre.text.toString()

            if (ad.equals("") || soyad.equals("") || email.equals("") || sifre.equals(""))
            {
                showToast("Lütfen Tüm Alanları Doldurunuz")
            }
            else
            {
                kullaniciKaydet(ad, soyad, email, sifre)
                showToast("Kayıt Başarılı")
                giriseGit()
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun kullaniciKaydet(ad: String, soyad: String, email: String, sifre: String) {
        editor.putString("ad", ad)
        editor.putString("soyad", soyad)
        editor.putString("email", email)
        editor.putString("sifre", sifre)
        editor.apply()
    }

    private fun giriseGit() {
        val intent = Intent(this, GirisActivity ::class.java)
        startActivity(intent)
    }
}
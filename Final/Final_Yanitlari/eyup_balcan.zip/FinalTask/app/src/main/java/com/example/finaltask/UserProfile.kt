package com.example.finaltask

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class UserProfile : AppCompatActivity() {
    lateinit var emailText: TextView
    lateinit var nameText: TextView
    lateinit var surnameText: TextView
    lateinit var logoutBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_profile)
        emailText = findViewById<EditText>(R.id.textViewEmail)
        nameText = findViewById<EditText>(R.id.textViewName)
        logoutBtn = findViewById<Button>(R.id.logoutBtn)

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = shared.edit()
        val name = shared.getString("name","")
        val surname = shared.getString("surname","")
        val mail = shared.getString("email","")
        emailText.setText(mail)
        nameText.setText("Sn. " +name + " " + surname)

        logoutBtn.setOnClickListener {
            editor.remove("name")
            editor.remove("surname")
            editor.remove("email")
            editor.remove("password")
            val i = Intent(this@UserProfile, MainActivity::class.java)
            startActivity(i)
            Toast.makeText(this@UserProfile, "Çıkış Yapıldı", Toast.LENGTH_LONG).show()
        }
    }
}
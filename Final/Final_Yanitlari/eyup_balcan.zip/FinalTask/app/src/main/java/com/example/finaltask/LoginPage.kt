package com.example.finaltask

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LoginPage : AppCompatActivity() {
    lateinit var emailText: EditText
    lateinit var passwordText: EditText
    lateinit var loginBtn: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val shared = getSharedPreferences("users", MODE_PRIVATE)
        val editor = shared.edit()

        emailText = findViewById<EditText>(R.id.emailTextLogin)
        passwordText = findViewById<EditText>(R.id.passwordTextLogin)
        loginBtn = findViewById<Button>(R.id.loginBtn)

        loginBtn.setOnClickListener {
            var email = emailText.text;
            var password = passwordText.text;

            val mail = shared.getString("email","")
            val pass = shared.getString("password","")
            val emailInput = emailText.text.toString()
            val passwordInput = passwordText.text.toString()
            if(emailText.text.isNotEmpty()&&passwordText.text.isNotEmpty()) {
                if (mail == emailInput && pass == passwordInput) {
                    val i = Intent(this@LoginPage, UserProfile::class.java )
                    startActivity(i)
                    Toast.makeText(this@LoginPage, "Başarıyla giriş yapıldı.", Toast.LENGTH_LONG).show()

                }
                else{
                    Toast.makeText(this@LoginPage, "Email ya da şifre yanlış", Toast.LENGTH_LONG).show()

                }
            }else{
                Toast.makeText(this@LoginPage, "Lütfen tüm alanları doldurunuz", Toast.LENGTH_LONG).show()

            }

        }

    }
}
package com.example.oguzbaransahingil

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class KullanicigirisiActivity : AppCompatActivity() {

    lateinit var txtMailView: TextView
    lateinit var txtParolaView: TextView
    lateinit var btnGiris : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kullanicigirisi)

        val shared = getSharedPreferences("appData", MODE_PRIVATE)
        val editor = shared.edit()

        val mail = shared.getString("Adı","")
        if (mail.equals("Oguz Baran")){
            val i = Intent(this@KullanicigirisiActivity,ProfileActivity::class.java)
            startActivity(i)
        }

        val soyadı = shared.getString("Soyadı","")
        if (soyadı.equals("Sahingil")){
            val i = Intent(this@KullanicigirisiActivity,ProfileActivity::class.java)
            startActivity(i)
        }

        txtMailView = findViewById(R.id.txtMailView)
        txtParolaView = findViewById(R.id.txtParolaView)
        btnGiris = findViewById(R.id.btnGiris)
        btnGiris.setOnClickListener {
            val mail = txtMailView.text.toString()
            editor.putString("adı",mail)
            val parola = txtParolaView.text.toString()
            editor.putString("soyadı",parola)
            Toast.makeText(this@KullanicigirisiActivity,"Giriş Başarılı Bir Şekilde Yapılmıştır.",Toast.LENGTH_LONG).show()

        }








    }
}
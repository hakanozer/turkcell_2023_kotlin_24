package com.example.oguzbaransahingil

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var txtAdı : EditText
    lateinit var txtSoyadı : EditText
    lateinit var txtMail : EditText
    lateinit var txtParola : EditText
    lateinit var btnSave : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val shared = getSharedPreferences("appData", MODE_PRIVATE);
        val editor = shared.edit()

        val adı = shared.getString("Adı","")
        if (adı.equals("Oguz Baran")){
            val i = Intent(this@MainActivity,KullanicigirisiActivity::class.java)
            startActivity(i)
        }

        val soyadı = shared.getString("Soyadı","")
        if (soyadı.equals("Sahingil")){
            val i = Intent(this@MainActivity,KullanicigirisiActivity::class.java)
            startActivity(i)
        }

        val mail= shared.getString("Adı","")
        if (mail.equals("oguz@mail.com")){
            val i = Intent(this@MainActivity,KullanicigirisiActivity::class.java)
            startActivity(i)
        }

        val parola = shared.getString("Parola","")
        if (parola.equals("oguzbaran")){
            val i = Intent(this@MainActivity,KullanicigirisiActivity::class.java)
            startActivity(i)
        }

        txtAdı = findViewById(R.id.txtAdı)
        txtSoyadı = findViewById(R.id.txtSoyadı)
        txtMail = findViewById(R.id.txtMail)
        txtParola = findViewById(R.id.txtParola)
        btnSave = findViewById(R.id.btnSave)
        btnSave.setOnClickListener {
            val adı = txtAdı.text.toString()
            editor.putString("adı",adı)
            val soyadı = txtSoyadı.text.toString()
            editor.putString("soyadı",soyadı)
            val mail = txtMail.text.toString()
            editor.putString("mail",mail)
            val parola = txtParola.toString()
            editor.putString("parola",parola)
            editor.commit()
            Toast.makeText(this@MainActivity,"Kayıt Başarılı Bir Şekilde Yapılmıştır.",Toast.LENGTH_LONG).show()

        }





    }
}
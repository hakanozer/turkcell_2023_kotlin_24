package com.atilla.turkcellfinal.activities

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Binder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.atilla.turkcellfinal.R
import com.atilla.turkcellfinal.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreference =  getSharedPreferences("user", Context.MODE_PRIVATE)
        val editor = sharedPreference.edit()

        val name = sharedPreference.getString("name", null)
        val surname = sharedPreference.getString("surName", null)
        val email = sharedPreference.getString("email", null)

        binding.tvProfileName.text = "Sn. $name $surname"
        binding.tvProfileEmail.text = email.toString()

        binding.ibLogOut.setOnClickListener {
            val i = Intent(this, SignUpActivity::class.java)
            editor.clear()
            editor.apply()
            startActivity(i)
        }
    }

}
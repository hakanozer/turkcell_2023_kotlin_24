package com.atilla.turkcellfinal.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.atilla.turkcellfinal.R
import com.atilla.turkcellfinal.databinding.ActivitySignInBinding

class SignInActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignInBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonGiris.setOnClickListener {
            val i = Intent(this, ProfileActivity::class.java)

            val sharedPreference =  getSharedPreferences("user", Context.MODE_PRIVATE)
            val editor = sharedPreference.edit()

            val email = sharedPreference.getString("email", null)
            val password = sharedPreference.getString("password", null)
            // val isLogged = sharedPreference.getBoolean("isLogged", false)

            val etEmail = binding.etEmailGiris.text.toString()
            val etPassword = binding.etPasswordGiris.text.toString()

            if(email != etEmail){
                Toast.makeText(this, "Lütfen kayıt olduğunuz email ile giriş yapınız", Toast.LENGTH_LONG).show()
            }
            else if (password != etPassword) {
                Toast.makeText(this, "Lütfen doğru şifre girdiğinizden emin olunuz", Toast.LENGTH_LONG).show()
            } else {

                // giriş eylemi başarılı olduğu vakit bir sonraki ugyulamanın açılışında otomatik giriş için isLogged True olarak verilir.
                editor.putBoolean("isLogged", true)
                startActivity(i)
            }

            editor.apply()
            // Toast.makeText(this, "$email  $password $isLogged", Toast.LENGTH_LONG).show()


        }
    }
}
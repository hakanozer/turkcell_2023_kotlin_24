package com.atilla.turkcellfinal.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.atilla.turkcellfinal.databinding.ActivitySignUpBinding

class SignUpActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignUpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Eğer daha önceden kayıdolmuş kullanıcı varsa, sonrasında başarılı şekilde logged olmuşsa ve çıkış yapmamışsa profil ekranına yönlendirir
        val sharedPreference =  getSharedPreferences("user", Context.MODE_PRIVATE)
        val editor = sharedPreference.edit()
        if(sharedPreference.getString("name", null) != null && sharedPreference.getBoolean("isLogged", false)) {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        editor.apply()

        binding.button.setOnClickListener {
            val i = Intent(this, SignInActivity::class.java)
            val inputCorrection = checkInputs()
            if(inputCorrection) {
                startActivity(i)
            }
        }
    }

    private fun checkInputs(): Boolean {
        val name = binding.etName.text.toString()
        val surname = binding.etSurname.text.toString()
        val email = binding.etEmail.text.toString()
        val password = binding.etPassword.text.toString()

        if (name == "") {
            Toast.makeText(this, "Lütfen isim giriniz", Toast.LENGTH_LONG).show()
        } else if (surname == ""){
            Toast.makeText(this, "Lütfen soyisim giriniz", Toast.LENGTH_LONG).show()
        } else if (email == ""){
            Toast.makeText(this, "Lütfen email giriniz", Toast.LENGTH_LONG).show()
        } else if (password == ""){
            Toast.makeText(this, "Lütfen parola giriniz", Toast.LENGTH_LONG).show()
        } else {
            if(!binding.checkBox.isChecked) {
                Toast.makeText(this, "Lütfen kvkk onaylayınız", Toast.LENGTH_LONG).show()
            } else {
                val sharedPreference =  getSharedPreferences("user", Context.MODE_PRIVATE)
                val editor = sharedPreference.edit()
                editor.putString("name", name)
                editor.putString("surName", surname)
                editor.putString("email", email)
                editor.putString("password", password)
                editor.apply()
                return true
            }
        }
        return false
        // Toast.makeText(this, "$name $surname $email $password", Toast.LENGTH_LONG).show()
    }
}

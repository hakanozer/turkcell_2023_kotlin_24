package com.example.myapplication2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private lateinit var name: EditText
    private lateinit var lastname: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var login: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById(R.id.name)
        lastname = findViewById(R.id.lastname)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        login = findViewById(R.id.login)

        login.setOnClickListener {
            val name = name.text.toString()
            val lastname = lastname.text.toString()
            val email = email.text.toString()
            val password = password.text.toString()

            // Perform registration logic
            kullaniciKayit(name, lastname, email, password)
        }

    }

    private fun kullaniciKayit(name: String, lastname: String, email: String, password: String) {
        Toast.makeText(this, "Başarılı", Toast.LENGTH_SHORT).show()
    }

}
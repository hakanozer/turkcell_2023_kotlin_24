package com.exap.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.exap.myapplication.databinding.ActivityMain2Binding


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMain2Binding //id'lere erişmek için
    lateinit var preferances: SharedPreferences //xml dosyasındaki bilgilere erişmek için
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=ActivityMain2Binding.inflate(LayoutInflater.from(applicationContext))
        setContentView(binding.root)
        preferances=getSharedPreferences("bilgiler", MODE_PRIVATE)

       binding.Girisbtn.setOnClickListener {
           var kayitlikullaniciMail=preferances.getString("kullaniciMail","")
           var kayitliparola=preferances.getString("parola","")
           var giriskullaniciMail=binding.GirisgirisKullaniciAdi.text.toString()
           var girisparola=binding.KayitgirisParola.text.toString()

           if((kayitlikullaniciMail==giriskullaniciMail)&&(kayitliparola==girisparola)&&(kayitlikullaniciMail!="")&&(kayitliparola!="")){
               intent = Intent(applicationContext,MainHosgeldiniz::class.java)
               startActivity(intent)
           }
           else{
               Toast.makeText(applicationContext,"Giriş bilgileri hatalı",Toast.LENGTH_LONG).show()
           }


       }
        binding.KayitOlbtn.setOnClickListener{
            intent= Intent(applicationContext,MainKayitol::class.java)
            startActivity(intent)
        }
    }
}
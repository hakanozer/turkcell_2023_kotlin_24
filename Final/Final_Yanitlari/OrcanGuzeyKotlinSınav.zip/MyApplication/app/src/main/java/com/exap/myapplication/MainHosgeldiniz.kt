package com.exap.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import com.exap.myapplication.databinding.ActivityMainHosgeldinizBinding

class MainHosgeldiniz : AppCompatActivity() {
    lateinit var preferences:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainHosgeldinizBinding.inflate(LayoutInflater.from(applicationContext))
        setContentView(binding.root)
        preferences =getSharedPreferences("bilgiler", MODE_PRIVATE)
        var kayitlikullaniciMail=preferences.getString("kullaniciMail","")
        var kayitliparola=preferences.getString("parola","")
        var kayitlikullaniciAdi=preferences.getString("kullaniciAdi","")
        var kayitliSoyaAdi=preferences.getString("kullaniciSoyadi","")
        binding.kullanicibilgisi.text="KULLANICI ADI \t"+  kayitlikullaniciAdi.toString()
        binding.textView.text="KULLANICI SOYADI \t"+kayitliSoyaAdi.toString()
        binding.textView2.text="KULLANICI MAIL ADRESİ \t"+kayitlikullaniciMail.toString()
        binding.textView3.text="KULLANICI PAROLASI \t"+kayitliparola.toString()
        binding.KayitbtnCikis.setOnClickListener{
            intent= Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)
            //xmlden verilerimizi cekelim


            //textviewlere kayitli bilgileri aktariyoruz
           finish()
        }

    }
}
package com.exap.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.exap.myapplication.databinding.ActivityMainHosgeldinizBinding
import com.exap.myapplication.databinding.ActivityMainKayitolBinding

class MainKayitol : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityMainKayitolBinding.inflate(LayoutInflater.from(applicationContext))
        setContentView(R.layout.activity_main_kayitol)
        setContentView(binding.root)
        binding.KayitbtnKaydet.setOnClickListener{
            var kullaniciMail=binding.KayitgirisKullaniciMailAdresi.text.toString()
            var kullaniciAdi=binding.AdGiris.text.toString()
            var kullaniciSoyAdi=binding.SoyAdGiris.text.toString()
            var kullaniciparola=binding.KayitgirisParola.text.toString()
            var sharedPreferences=this.getSharedPreferences("bilgiler", MODE_PRIVATE)
            var editor=sharedPreferences.edit()

            editor.putString("kullaniciAdi","$kullaniciAdi").apply()
            editor.putString("kullaniciSoyadi","$kullaniciSoyAdi").apply()
            editor.putString("kullaniciMail","$kullaniciMail").apply()
            editor.putString("parola","$kullaniciparola").apply()
            Toast.makeText(applicationContext,"Kayıt Başarılı",Toast.LENGTH_LONG).show()
            binding.KayitgirisKullaniciMailAdresi.text.clear()
            binding.KayitgirisParola.text.clear()
            binding.SoyAdGiris.text.clear()
            binding.AdGiris.text.clear()
        }




        binding.btnGiriseDon.setOnClickListener{
            intent= Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)
        }
    }
}
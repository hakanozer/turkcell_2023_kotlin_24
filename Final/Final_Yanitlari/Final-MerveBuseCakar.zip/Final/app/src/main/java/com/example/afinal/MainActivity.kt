package com.example.afinal
/* import android.content.Intent */
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Button
import android.widget.EditText
import com.example.afinal.R

class MainActivity : AppCompatActivity() {
    lateinit var txtname: EditText
    lateinit var txtsurname: EditText
    lateinit var txtsifre: EditText
    lateinit var txtmail: EditText
    lateinit var Button: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtname = findViewById(R.id.txtname)
        txtsurname = findViewById(R.id.txtsurname)
        txtsifre = findViewById(R.id.txtsifre)
        txtmail = findViewById(R.id.txtmail)
        Button = findViewById(R.id.Button)


        Button.setOnClickListener {
            val intent = Intent(this, ContactsContract.Profile::class.java)
            val txt= txtname.text.toString()
            val txt1= txtsurname.text.toString()
            val txt2= txtsifre.text.toString()
            val txt3= txtmail.text.toString()
            intent.putExtra("key1","data1")
            startActivity(intent)
        }
    }
}